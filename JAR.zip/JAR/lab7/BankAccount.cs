﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
   abstract class BankAccount
    {
       // Private -String  name, string  accNo, string  gender, string  phoneNo, String address
        private string name;
        private string accNo;
        private string gender;
        private string phoneNo;
        private string address;
        private double balance;

      



        public string Name
        {
            set { name = value; }
            get { return name; }
        }


        public string AccNo
        {
            set { accNo = value; }
            get { return accNo; }
        }


        public string Gender
        {
            set { gender = value; }
            get { return gender; }
        }

        public string PhoneNo
        {
            set { phoneNo = value; }
            get { return phoneNo; }
        }


        public string Address
        {
            set { address = value; }
            get { return address; }
        }


        public double Balance
        {
            set { balance = value; }
            get { return balance; }
        }



      public  abstract void showInfo();



    }
}
