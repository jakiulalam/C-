﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
    class Program
    {
        static void Main(string[] args)
        {



            SavingsAccount jar = new SavingsAccount();

            jar.Name = "jar";
            jar.AccNo = "ACN066";
            jar.Balance = 6000.0;
            jar.Gender = "Male";
            jar.PhoneNo = "1770751986";
            jar.Address = "mirpur";

            jar.Deposit(4000);
           jar.Withdraw(5000);
            jar.showInfo();

            CurrentAccount jarr = new CurrentAccount();
            jarr.Name = "jar";
            jarr.AccNo = "ACN0666";
            jarr.Balance = 80000.0;
            jarr.Gender = "Male";
            jarr.PhoneNo = "17";
            jarr.Address = "Mohammadpur";

            jarr.Deposit(4000);
            jarr.Withdraw(16000);
            jarr.showInfo();



























        }
    }
}
