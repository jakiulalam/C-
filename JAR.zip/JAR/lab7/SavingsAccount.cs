﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab7
{
    class SavingsAccount:BankAccount,IBankAccount
    {


          public void Deposit(double amount)
        {
            this.Balance = this.Balance + amount;
        }

         public void Withdraw(double amount)
         {
             if (amount <= 5000)
             { Balance = Balance - amount; }
           

         }


         public override void showInfo()
         {
             Console.WriteLine("Name: " + this.Name);
             Console.WriteLine("Account No: " + this.AccNo);
             Console.WriteLine("Balance: " + this.Balance);
             Console.WriteLine("Gender: " + this.Gender);
             Console.WriteLine("Phone: " + this.PhoneNo);
             Console.WriteLine("Address: " + this.Address);


         }













    }




}
