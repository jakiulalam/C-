﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4a
{
    class student: person

    {

      protected  double cgpa;
 protected string department;
 protected int creditCompleted;


 public student()
 { Console.WriteLine("empty"); }

 public student(double cg, String dp, int cc)
 {
     cgpa = cg;
     department = dp;
     creditCompleted = cc;
 }


        public void showInfo()
{   

    Console.WriteLine(name+id+gender+phoneNo+address+cgpa+department+creditCompleted);


}

public double Cgpa{

    set{cgpa=value;}
    get{return cgpa;}
}

        public string Department{
            set{department=value;}
            get{return department;}
        }


        public int CreditCompleted{


            set{creditCompleted=value;}
            get{ return creditCompleted;}
        }




















    }
}
