﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4a
{
    class Program
    {
        static void Main(string[] args)
        {

            student p = new student();
            p.Name = "jar";
            p.Id = 606;
            p.Gender='m';
            p.PhoneNo="0177000000";
            p.Address="kuratoli";
            p.Department = "cse";
            p.Cgpa = 3.33;
            p.CreditCompleted = 110;
           

          

           
            p.showInfo();


           student s = new student();
            s.Cgpa=3.56;
            s.Department= "cse";
            s.CreditCompleted = 100;
            s.Name = "jak";
            s.Id = 777;
            s.Gender = 'm';
            s.PhoneNo="0177777777";
            s.Address = "khilkhet";

            

            s.showInfo();

        }
    }
}
