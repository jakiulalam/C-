﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task4a
{
    class person
    {



     protected string name;
      protected int id;
protected char gender;
protected string phoneNo;
protected string address;


public person()
{
    Console.WriteLine("empty");
}

public person(string nm, int i, char gen, string pn, string add)
{
    name = nm;
    id = i;
    gender = gen;
    phoneNo = pn;
    address = add;
}


public void showInfo()
{   

    Console.WriteLine(name+id+gender+phoneNo+address);


}

public string Name{



    set{name=value;}
    get{return name;}
}


public int Id{


    set{id=value;}
    get{return id;}


}

public char Gender{


    set{gender=value;}
    get{return gender;}
}


public string PhoneNo{

    set{phoneNo=value;}
    get{return phoneNo;}
}


        public string Address{



            set{address=value;}
            get{ return address;}
        }











    }
}
