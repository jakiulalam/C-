﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        float num, ans;
        int count;
        



        public void disable()
        {
            textBox1.Enabled = false;
            button1.Show();
            button5.Hide();
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;
            button7.Enabled = false;
            button8.Enabled = false;
            button9.Enabled = false;
            button10.Enabled = false;
            button12.Enabled = false;
            button13.Enabled = false;
            button14.Enabled = false;
            button15.Enabled = false;
            button17.Enabled = false;
            button18.Enabled = false;
            button19.Enabled = false;
            button20.Enabled = false;
            button22.Enabled = false;
            button24.Enabled = false;
            button25.Enabled = false;
          
            


        }


        public void enable()
        {




            textBox1.Enabled = true;
            button5.Show();
            button1.Hide();
            button2.Enabled = true;
            button3.Enabled = true;
            button4.Enabled = true;
            button7.Enabled = true;
            button8.Enabled = true;
            button9.Enabled = true;
            button10.Enabled =true;
            button12.Enabled =true;
            button13.Enabled =true;
            button14.Enabled =true;
            button15.Enabled =true;
            button17.Enabled =true;
            button18.Enabled =true;
            button19.Enabled =true;
            button20.Enabled =true;
            button22.Enabled =true;
            button24.Enabled =true;
            button25.Enabled = true;
                

        }




        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int lenght = textBox1.TextLength - 1;
            string text = textBox1.Text;
            textBox1.Clear();

            for (int i = 0; i < lenght; i++)
                textBox1.Text = textBox1.Text + text[i];



        }

        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
            enable();
        }

        private void button24_Click(object sender, EventArgs e)
        {

            //display(.)

            if(button24.Text.Contains("."))
            {

                if (!textBox1.Text.Contains("."))
                    textBox1.Text = textBox1.Text + ".";



            } else

            textBox1.Text = textBox1.Text + ".";



        }

        private void button25_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();

            textBox1.Text = textBox1.Text + 0;
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 1;
        }

        private void button19_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 2;
        }

        private void button18_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 3;
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 4;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 5;
        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 6;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 7;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 8;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "0")
                textBox1.Clear();
            textBox1.Text = textBox1.Text + 9;
        }

        private void button5_Click(object sender, EventArgs e)
        {     
            textBox1.Text = "";
            disable();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {    

          /*  if(num!=0)
            {
                button22.PerformClick();
                operation = button4.Text;
                label1.Text = num.ToString() + "+";


            }else*/


            num = float.Parse(textBox1.Text);
            textBox1.Clear();
            textBox1.Focus();
            count = 1;
            label1.Text = num.ToString() + "+";
           
        }

        private void button7_Click(object sender, EventArgs e)
        {


            num = float.Parse(textBox1.Text);
            textBox1.Clear();
            textBox1.Focus();
            count = 2;
            label1.Text = num.ToString() + "-";



        }

        private void button12_Click(object sender, EventArgs e)
        {




            num = float.Parse(textBox1.Text);
            textBox1.Clear();
            textBox1.Focus();
            count = 3;
            label1.Text = num.ToString() + "*";
        }

        private void button17_Click(object sender, EventArgs e)
        {


            num = float.Parse(textBox1.Text);
            textBox1.Clear();
            textBox1.Focus();
            count = 4;
            label1.Text = num.ToString() + "/";


        }

        private void button22_Click(object sender, EventArgs e)
        {
            compute();
            label1.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox1.Text = "0";
          
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void compute()

        {

            switch(count)
            {


                case 1:
                    ans = num + float.Parse(textBox1.Text);
                    textBox1.Text = ans.ToString();
                    break;



                case 2:
                    ans = num - float.Parse(textBox1.Text);
                    textBox1.Text = ans.ToString();
                    break;



                case 3:
                    ans = num * float.Parse(textBox1.Text);
                    textBox1.Text = ans.ToString();
                    break;




                case 4:
                    ans = num / float.Parse(textBox1.Text);
                    textBox1.Text = ans.ToString();
                    break;



                default:

                    break;












            }




          












        }

















    }
}
