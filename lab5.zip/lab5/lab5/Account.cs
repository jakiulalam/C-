﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    class Account
    {
        protected string accountHolderName;
        protected string accountId;
        protected double balance;


 public Account()
 {

     Console.WriteLine("empty");
 }


 public Account(string AccounterHolderName, string AccountId, double Balance)
 {
     accountHolderName = AccounterHolderName;
     accountId = AccountId;
     balance = Balance;
 }



 public string AccountHolderName
 {
     set { accountHolderName = value; }
     get { return accountHolderName; }
 }


 public string AccountId
 {
     set { accountId = value; }
     get { return accountId; }
 }

 public double Balance
 {
     set { balance = value; }
     get { return balance; }
 }



 public void depositCash(double ammount)
 {
     if (ammount > 0)
     {
         balance = balance + ammount;
     }
     else

     { Console.WriteLine("invalid deposit ammount"); }
 }



 public void withdrawcash(double ammount)
 {
     if (ammount > 0 && ammount <= balance)
     { balance = balance - ammount; }
     else { Console.WriteLine("invalid withdraw ammount"); }
 }



 public void transferCash(Account a, double ammount)
 {
     if (ammount > 0 && balance >= ammount)
     {
         withdrawcash(ammount);
         a.depositCash(ammount);
     }
     else { Console.WriteLine("invalid transfer"); }
 }



 public void showInfo()
 { Console.WriteLine(accountHolderName + accountId + balance); }























    }
}
