﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    class Program
    {
        static void Main(string[] args)
        {



            Account a1 = new Account();
            Account a2 = new Account("Jar", "6", 5000);

            a1.AccountHolderName = "Jak";
            a1.AccountId = "5";
            a1.Balance = 6000;

            a1.depositCash(1000);
            a1.withdrawcash(500);
            a1.transferCash(a2, 2000);

            a1.showInfo();
            a2.showInfo();

            Bank b1 = new Bank("Rupali Bank", "Dhaka");
            b1.addAccount(a1);
            b1.addAccount(a2);
            b1.showInfo();

















        }
    }
}
