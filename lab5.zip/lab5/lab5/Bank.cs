﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab5
{
    class Bank
    {

        protected string bankname;
        protected string address;
        protected Account[] account;


        public Bank()
        { Console.WriteLine("empty"); }

        public Bank(string BankName, string Address)
        {

            bankname = BankName;
            address = Address;
            account = new Account[5];
        }




        public string Bankname
        {
            set { bankname = value; }
            get { return bankname; }
        }


        public string Address
        {
            set { address = value; }
            get { return address; }
        }



        public void addAccount(Account a)
        {

            for (int i = 0; i < account.Length; i++)
            {
                account[i] = a;
            }
        
        

        public void deleteAccount(Account a)
        {
        
            for (int i = 0; i < account.Length; i++)
            {
                if (account[i] == a)
                {
                    account[i]=null;
        
        
        
        
        }


   public void showInfo()
        {
         
            Console.WriteLine("Bank Name: " + bankname);
            Console.WriteLine("Address: " + address);
            for (int i = 0; i < account.Length; i++)
            {
                Console.WriteLine("Account: " + this.account[i].AccountHolderName);
            }
        
        
        }


























    }
}
